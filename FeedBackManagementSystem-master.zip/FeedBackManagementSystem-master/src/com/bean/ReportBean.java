package com.bean;

public class ReportBean {

	private int userId,attendance,logic,comm,grasping;
	private String subject,date,faculty;
	public void setUserId(int userId) {
		this.userId = userId;
		
	}
	public int getUserId() {
		// TODO Auto-generated method stub
		return userId;
		

	}
	public void setSubject(String subject) {
		// TODO Auto-generated method stub
		this.subject=subject;
		
	}
	public String getSubject() {
		// TODO Auto-generated method stub
		return subject;
		

	}
	public void setAttendance(int attendance) {
		// TODO Auto-generated method stub
		this.attendance=attendance;
		
	}
	public int getAttendance() {
		// TODO Auto-generated method stub
		return attendance;
		

	}
	public void setLogic(int logic) {
		// TODO Auto-generated method stub
		this.logic=logic;
		
	}
	public int getLogic() {
		// TODO Auto-generated method stub
		return logic;
		

	}
	public void setComm(int comm) {
		// TODO Auto-generated method stub
		this.comm=comm;
		
	}
	public int getComm() {
		// TODO Auto-generated method stub
		return comm;
		

	}
	public void setGrasping(int grasping) {
		// TODO Auto-generated method stub
		this.grasping=grasping;
		
	}
	public int getGrasping() {
		// TODO Auto-generated method stub
		return grasping;
		

	}
	public void setDate(String date) {
		// TODO Auto-generated method stub
		this.date=date;
		
	}
	public String getDate() {
		// TODO Auto-generated method stub
		return date;
		

	}
	public void setFaculty(String faculty) {
		// TODO Auto-generated method stub
		this.faculty=faculty;
		
	}
	public String getFaculty() {
		// TODO Auto-generated method stub
		return faculty;
		

	}

}
